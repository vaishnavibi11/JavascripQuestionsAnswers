const booleanNo = (num) => {
    return num % 10 === 0 ? true : false
}

console.log(booleanNo(55))