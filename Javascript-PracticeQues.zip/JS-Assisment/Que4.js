const name = "  Vaishnavi Bidarkar  ";
console.log(name.trim());