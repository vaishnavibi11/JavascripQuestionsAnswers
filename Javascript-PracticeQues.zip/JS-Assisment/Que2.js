let array = [5,10,15,20,25];
let sum = 0;
for (let i=0;i<array.length;i++)
{
    sum = sum+array[i];
}
console.log(sum);