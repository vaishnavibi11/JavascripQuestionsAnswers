const menuOfDay = day => {
    switch(day) {
      case 'Monday':
        return 'Veg Pulav';
      case 'Tuesday':
        return 'Sandwich';
      case 'Wednesday':
        return 'Coffee';
      case 'Thursday':
        return 'Rice';
      case 'Friday':
        return 'Pizza';
      case 'Saturday':
        return 'Burger';
      case 'Sunday':
        return 'Maggie';
      default:
        return 'Invalid day';
    }
  };
  
  
  console.log(menuOfDay('Monday')); 
  console.log(menuOfDay('Wednesday')); 
  console.log(menuOfDay('Friday')); 
  console.log(menuOfDay('InvalidDay'));