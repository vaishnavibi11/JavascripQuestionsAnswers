const companyEmployees = {
    employee1: {
      id: "10",
      name: "Neha Mane",
      position: "Software Engineer",
      department: "Development",
    },
    employee2: {
      id: "11",
      name: "Sakshi Joshi",
      position: "Project Manager",
      department: "Project Management",
    },
    employee3: {
      id: "12",
      name: "Vaishnavi Jadhav",
      position: "UX Designer",
      department: "Design",
    }
   
  };
  
 
  console.log(companyEmployees.employee1);
  console.log(companyEmployees);