let string1 = "Hello";
let string2 = "World";
console.log("String concatenation is:",string1+string2);